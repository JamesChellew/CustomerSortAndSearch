package objects

import java.io.Serializable


class Customer(var id: Int, var name: String, var email: String, var mobile: String) : Serializable